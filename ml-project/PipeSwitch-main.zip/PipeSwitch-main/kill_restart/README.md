# Kill and restart
This folder contains code for kill-and-restart.

# Environment
You need to add the path to the repo to `PYTHONPATH`.

# Usage
```
python kill_restart.py
```
# Util

This folder contains some common codes which are used in multiple programs.
One function is print timestamp with labels.
The other is to simplify TCP interface.